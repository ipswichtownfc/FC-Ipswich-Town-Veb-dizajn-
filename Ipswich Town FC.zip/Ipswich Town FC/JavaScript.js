document.addEventListener("DOMContentLoaded", function() {
    let trenutniSlajd = 0;
    const slajdovi = document.querySelectorAll(".slajd");
    const brojSlajdova = slajdovi.length;
    const slajdoviPoStrani = 3;
    
    function prikaziSlajd(n) {
        const slajder = document.querySelector(".slajdovi");
        if (n >= brojSlajdova / slajdoviPoStrani) {
            trenutniSlajd = 0;
        } else if (n < 0) {
            trenutniSlajd = Math.floor(brojSlajdova / slajdoviPoStrani) - 1;
        } else {
            trenutniSlajd = n;
        }
        slajder.style.transform = `translateX(-${trenutniSlajd * 100}%)`;
    }

    function promeniSlajd(n) {
        prikaziSlajd(trenutniSlajd + n);
    }

    prikaziSlajd(trenutniSlajd);

    document.querySelector(".prev").addEventListener("click", function() {
        promeniSlajd(-1);
    });

    document.querySelector(".next").addEventListener("click", function() {
        promeniSlajd(1);
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Dodavanje event listener-a za formu
    document.getElementById("forma-komentara").addEventListener("submit", function(event) {
        event.preventDefault(); // Zaustavi podrazumevano ponašanje forme

        // Uzimanje vrednosti unetih u formu
        let ime = document.getElementById("ime").value;
        let email = document.getElementById("email").value;
        let komentar = document.getElementById("komentar").value;

        // Kreiranje objekta za komentar
        let noviKomentar = {
            ime: ime,
            email: email,
            komentar: komentar
        };

        // Uzimanje postojećih komentara iz LocalStorage-a
        let postojeciKomentari = JSON.parse(localStorage.getItem("komentari")) || [];

        // Dodavanje novog komentara u niz
        postojeciKomentari.push(noviKomentar);

        // Sačuvaj ažuriranu listu komentara u LocalStorage
        localStorage.setItem("komentari", JSON.stringify(postojeciKomentari));

        // Kreiranje HTML elementa za prikaz komentara
        let divKomentar = document.createElement("div");
        divKomentar.classList.add("komentar");
        divKomentar.innerHTML = `<strong>${ime}</strong> (${email}):<br>${komentar}`;

        // Dodavanje komentara u div za prikaz komentara
        let prikazKomentara = document.getElementById("prikaz-komentara");
        prikazKomentara.appendChild(divKomentar);

        // Resetovanje forme nakon dodavanja komentara
        document.getElementById("forma-komentara").reset();
    });

    // Funkcija za prikaz komentara iz LocalStorage-a prilikom učitavanja stranice
    function prikaziSacuvaneKomentare() {
        let postojeciKomentari = JSON.parse(localStorage.getItem("komentari")) || [];

        let prikazKomentara = document.getElementById("prikaz-komentara");
        prikazKomentara.innerHTML = "";

        postojeciKomentari.forEach(function(komentar) {
            let divKomentar = document.createElement("div");
            divKomentar.classList.add("komentar");
            divKomentar.innerHTML = `<strong>${komentar.ime}</strong> (${komentar.email}):<br>${komentar.komentar}`;
            prikazKomentara.appendChild(divKomentar);
        });
    }

    // Pozivanje funkcije za prikaz komentara prilikom učitavanja stranice
    prikaziSacuvaneKomentare();
});